<html>
    <head>
        <title>Link | Cadastrar</title>

    </head>    
    <body>
        <h3>Link | Cadastrar</h3>
        <form method="post" action="cLinks.php">
            Título:
            <input type="text" name="titulo">
            </br>
            Url:  
            <input type="text" name="link">
            <br/>
            Ativo:
            <select name="bolAtivo">
                <option value="XX">Selecione</option>
                <option value="1">Sim</option>
                <option value="0">Não</option>
            </select>
            <br>
            <input type="submit" value="CADASTRAR">
            
        </form>
      
            

</html>